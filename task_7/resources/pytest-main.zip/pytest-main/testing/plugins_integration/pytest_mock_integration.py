def test_mocker(mocker):
    mocker.MagicMock()
